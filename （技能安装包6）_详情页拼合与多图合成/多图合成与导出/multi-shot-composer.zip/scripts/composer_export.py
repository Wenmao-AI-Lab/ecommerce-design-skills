# -*- coding: utf-8 -*-
"""把合成图导出为各平台尺寸。

用法：
  python composer_export.py --input _r/九宫格/合成图.png --platforms 淘宝,小红书 --out _r/导出
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir, parse_platforms, PLATFORMS, slugify  # noqa


def plat_dirname(k):
    return PLATFORMS[k]['name'].replace('/', '-').replace('\\', '-').strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--platforms', required=True)
    ap.add_argument('--mode', default='width', choices=['width', 'cover', 'contain'],
                    help='width=只等比缩到平台宽；cover/contain=按平台主图尺寸处理')
    ap.add_argument('--suffix', default='')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    if not os.path.isfile(a.input):
        raise SystemExit('输入不存在：%s' % a.input)
    plats = parse_platforms(a.platforms)

    from PIL import Image
    src = Image.open(a.input).convert('RGB')
    sw, sh = src.size

    outdir = ensure_dir(a.out)
    records = []
    for pk in plats:
        pw, ph = PLATFORMS[pk]['main']
        if a.mode == 'width':
            tw = pw
            th = max(1, int(sh * (pw / sw)))
            out = src.resize((tw, th), 1)
        elif a.mode == 'cover':
            s = max(pw / sw, ph / sh)
            nw, nh = max(1, int(sw * s)), max(1, int(sh * s))
            r = src.resize((nw, nh), 1)
            out = r.crop(((nw - pw) // 2, (nh - ph) // 2, (nw - pw) // 2 + pw, (nh - ph) // 2 + ph))
        else:
            s = min(pw / sw, ph / sh)
            nw, nh = max(1, int(sw * s)), max(1, int(sh * s))
            r = src.resize((nw, nh), 1)
            out = Image.new('RGB', (pw, ph), (255, 255, 255))
            out.paste(r, ((pw - nw) // 2, (ph - nh) // 2))

        d = ensure_dir(os.path.join(outdir, plat_dirname(pk)))
        base = os.path.splitext(os.path.basename(a.input))[0]
        fn = slugify(base + a.suffix) + '.jpg'
        fp = os.path.join(d, fn)
        if os.path.isfile(fp):
            raise SystemExit('产物重名：%s' % fp)
        out.save(fp, quality=94)
        records.append({'platform': PLATFORMS[pk]['name'], 'dir': plat_dirname(pk),
                        'file': fn, 'size': list(out.size), 'mode': a.mode})

    assert len(records) > 0
    names = [r['file'] for r in records]
    with open(os.path.join(outdir, '导出报告.json'), 'w', encoding='utf-8') as f:
        json.dump({'source': os.path.basename(a.input), 'source_size': [sw, sh],
                   'n': len(records), 'records': records}, f, ensure_ascii=False, indent=2)

    print('导出完成：%d 个平台' % len(records))
    for r in records:
        print('  %-10s %dx%d  %s' % (r['platform'], r['size'][0], r['size'][1],
                                     os.path.join(r['dir'], r['file'])))
    print('输出：%s' % outdir)


if __name__ == '__main__':
    main()
