# -*- coding: utf-8 -*-
"""多图合成：九宫格 / 长图 / 双列 / 对比 / 瀑布流 / 一大四小。

用法：
  python composer.py --list
  python composer.py --layout grid3 --input 细节图/ --labels labels.json --out _r/九宫格
  python composer.py --layout strip --input 1.jpg,2.jpg,3.jpg --width 790 --out _r/长图
  python composer.py --layout grid3 --input a/ --unit 400x400 --unify-wb --out _r/九宫格
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir, get_font, rel_lum  # noqa

IMGS = ('.png', '.jpg', '.jpeg', '.webp')

LAYOUTS = {
    'grid3':   {'desc': '九宫格 3×3（不足 9 张自动补位为 N×M）', 'gap': 12, 'pad': 12},
    'grid2':   {'desc': '四宫格 2×2', 'gap': 14, 'pad': 14},
    'strip':   {'desc': '纵向长图（单列依次排列）', 'gap': 10, 'pad': 10},
    'strip2':  {'desc': '双列长图', 'gap': 12, 'pad': 12},
    'compare': {'desc': '左右对比（把前一半放左，后一半放右）', 'gap': 20, 'pad': 20},
    'masonry': {'desc': '瀑布流（双列，高度自适应）', 'gap': 10, 'pad': 10},
    'hero':    {'desc': '一大四小（首图放大，其余四个小图在下方）', 'gap': 12, 'pad': 12},
}


def load_inputs(raw, d):
    files = []
    for x in raw:
        if os.path.isdir(x):
            for n in sorted(os.listdir(x)):
                if n.lower().endswith(IMGS):
                    files.append(os.path.join(x, n))
        elif os.path.isfile(x):
            files.append(x)
    if d and os.path.isdir(d):
        for n in sorted(os.listdir(d)):
            if n.lower().endswith(IMGS):
                files.append(os.path.join(d, n))
    # 去重但保序
    seen, out = set(), []
    for f in files:
        a = os.path.abspath(f)
        if a not in seen:
            seen.add(a)
            out.append(a)
    return out


def mean_color(im):
    """粗略平均色（用于统一白平衡）。"""
    small = im.resize((16, 16), 1)
    px = small.load()
    w, h = small.size
    n = w * h
    r = sum(px[x, y][0] for x in range(w) for y in range(h)) // n
    g = sum(px[x, y][1] for x in range(w) for y in range(h)) // n
    b = sum(px[x, y][2] for x in range(w) for y in range(h)) // n
    return (r, g, b)


def unify_wb(img, target):
    """把各图平均色往目标（整体均值）靠，消除色温跳变。"""
    from PIL import Image
    cur = mean_color(img)
    px = img.load()
    w, h = img.size
    out = Image.new('RGB', (w, h))
    op = out.load()
    for y in range(h):
        for x in range(w):
            r, g, b = px[x, y]
            nr = min(255, max(0, int(r * (target[0] / max(1, cur[0])))))
            ng = min(255, max(0, int(g * (target[1] / max(1, cur[1])))))
            nb = min(255, max(0, int(b * (target[2] / max(1, cur[2])))))
            op[x, y] = (nr, ng, nb)
    return out


def fit_unit(im, uw, uh, mode='cover'):
    from PIL import Image
    w, h = im.size
    if mode == 'cover':
        s = max(uw / w, uh / h)
        nw, nh = max(1, int(w * s)), max(1, int(h * s))
        r = im.resize((nw, nh), 1)
        return r.crop(((nw - uw) // 2, (nh - uh) // 2, (nw - uw) // 2 + uw, (nh - uh) // 2 + uh))
    else:
        s = min(uw / w, uh / h)
        nw, nh = max(1, int(w * s)), max(1, int(h * s))
        r = im.resize((nw, nh), 1)
        canvas = Image.new('RGB', (uw, uh), (255, 255, 255))
        canvas.paste(r, ((uw - nw) // 2, (uh - nh) // 2))
        return canvas


def build(layout, imgs, unit, gap, pad, labels, unify, fit, index_start=1):
    from PIL import Image, ImageDraw
    cfg = LAYOUTS[layout]

    # 统一白平衡
    if unify and len(imgs) > 1:
        means = [mean_color(i) for i in imgs]
        target = tuple(sum(m[i] for m in means) // len(means) for i in range(3))
        imgs = [unify_wb(i, target) for i in imgs]

    uw, uh = unit
    n = len(imgs)
    placements = []

    if layout in ('grid3', 'grid2'):
        cols = 3 if layout == 'grid3' else 2
        rows = (n + cols - 1) // cols
        W = pad * 2 + cols * uw + (cols - 1) * gap
        H = pad * 2 + rows * uh + (rows - 1) * gap
        canvas = Image.new('RGB', (W, H), (255, 255, 255))
        for i, im in enumerate(imgs):
            r, c = divmod(i, cols)
            x = pad + c * (uw + gap)
            y = pad + r * (uh + gap)
            canvas.paste(fit_unit(im, uw, uh, fit), (x, y))
            placements.append({'i': i + 1, 'box': [x, y, uw, uh], 'grid': [r, c]})

    elif layout == 'strip':
        W = pad * 2 + uw
        H = pad * 2 + n * uh + (n - 1) * gap
        canvas = Image.new('RGB', (W, H), (255, 255, 255))
        for i, im in enumerate(imgs):
            y = pad + i * (uh + gap)
            canvas.paste(fit_unit(im, uw, uh, fit), (pad, y))
            placements.append({'i': i + 1, 'box': [pad, y, uw, uh]})

    elif layout == 'strip2':
        rows = (n + 1) // 2
        W = pad * 2 + 2 * uw + gap
        H = pad * 2 + rows * uh + (rows - 1) * gap
        canvas = Image.new('RGB', (W, H), (255, 255, 255))
        for i, im in enumerate(imgs):
            r, c = divmod(i, 2)
            x = pad + c * (uw + gap)
            y = pad + r * (uh + gap)
            canvas.paste(fit_unit(im, uw, uh, fit), (x, y))
            placements.append({'i': i + 1, 'box': [x, y, uw, uh], 'grid': [r, c]})

    elif layout == 'compare':
        half = (n + 1) // 2
        left, right = imgs[:half], imgs[half:]
        rows = max(len(left), len(right))
        W = pad * 2 + 2 * uw + gap
        H = pad * 2 + rows * uh + (rows - 1) * gap
        canvas = Image.new('RGB', (W, H), (255, 255, 255))
        for i, im in enumerate(left):
            y = pad + i * (uh + gap)
            canvas.paste(fit_unit(im, uw, uh, fit), (pad, y))
            placements.append({'i': i + 1, 'side': 'left', 'box': [pad, y, uw, uh]})
        for i, im in enumerate(right):
            y = pad + i * (uh + gap)
            x = pad + uw + gap
            canvas.paste(fit_unit(im, uw, uh, fit), (x, y))
            placements.append({'i': half + i + 1, 'side': 'right', 'box': [x, y, uw, uh]})

    elif layout == 'masonry':
        col_h = [pad, pad]
        boxes = []
        for im in imgs:
            c = 0 if col_h[0] <= col_h[1] else 1
            w0, h0 = im.size
            nh = max(1, int(uh * (h0 / w0)) if uh else uh)
            nh = min(nh, int(uh * 1.4))
            boxes.append((c, col_h[c], nh))
            col_h[c] += nh + gap
        W = pad * 2 + 2 * uw + gap
        H = max(col_h) - gap + pad
        canvas = Image.new('RGB', (W, H), (255, 255, 255))
        for i, (im, (c, y, nh)) in enumerate(zip(imgs, boxes)):
            x = pad + c * (uw + gap)
            canvas.paste(fit_unit(im, uw, nh, fit), (x, y))
            placements.append({'i': i + 1, 'box': [x, y, uw, nh], 'col': c})

    elif layout == 'hero':
        if n < 2:
            raise SystemExit('hero 版式至少需要 2 张图（1 大 + N 小）')
        big_w = pad * 2 + 2 * uw + gap
        smaller = imgs[1:5]
        sh = uh
        rows = 1
        H = pad * 2 + uh * 2 + gap + sh * rows
        canvas = Image.new('RGB', (big_w, H), (255, 255, 255))
        big = fit_unit(imgs[0], big_w - pad * 2, uh * 2, fit)
        canvas.paste(big, (pad, pad))
        placements.append({'i': 1, 'role': 'hero', 'box': [pad, pad, big_w - pad * 2, uh * 2]})
        cols = max(1, len(smaller))
        sw = (big_w - pad * 2 - (cols - 1) * gap) // max(1, cols)
        for i, im in enumerate(smaller):
            x = pad + i * (sw + gap)
            y = pad + uh * 2 + gap
            canvas.paste(fit_unit(im, sw, sh, fit), (x, y))
            placements.append({'i': i + 2, 'role': 'small', 'box': [x, y, sw, sh]})

    else:
        raise SystemExit('未知版式：%s' % layout)

    # 编号角标
    if labels:
        d = ImageDraw.Draw(canvas, 'RGBA')
        f = get_font(max(14, int(min(uw, uh) * 0.09)), bold=True)
        for p in placements:
            lb = labels.get(str(p['i']))
            if not lb:
                continue
            x, y, w0, h0 = p['box']
            txt = '%d. %s' % (index_start + p['i'] - 1, lb)
            tw = d.textbbox((0, 0), txt, font=f)[2]
            th = d.textbbox((0, 0), txt, font=f)[3]
            bx, by = x + 8, y + 8
            d.rectangle([bx, by, bx + tw + 16, by + th + 10], fill=(0, 0, 0, 140))
            d.text((bx + 8, by + 5), txt, font=f, fill=(255, 255, 255))

    return canvas, placements


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--layout')
    ap.add_argument('--input', nargs='*', default=[])
    ap.add_argument('--dir')
    ap.add_argument('--unit', help='WxH，默认按版式推导')
    ap.add_argument('--width', type=int, help='指定总宽，自动推导单元尺寸')
    ap.add_argument('--labels', help='JSON: {"1":"正视图","2":"侧面细节"}')
    ap.add_argument('--unify-wb', action='store_true', help='统一白平衡')
    ap.add_argument('--fit', default='cover', choices=['cover', 'contain'])
    ap.add_argument('--out')
    a = ap.parse_args()

    if a.list:
        print('可用版式：')
        for k, v in LAYOUTS.items():
            print('  %-9s %s' % (k, v['desc']))
        return

    if not a.layout:
        raise SystemExit('缺少 --layout（用 --list 查看可选版式）')
    if a.layout not in LAYOUTS:
        raise SystemExit('未知版式：%s（用 --list 查看可选版式）' % a.layout)
    if not a.out:
        raise SystemExit('缺少 --out')

    imgs_paths = load_inputs(a.input, a.dir)
    if not imgs_paths:
        raise SystemExit('没有输入图片')

    from PIL import Image
    imgs = []
    bad = []
    for p in imgs_paths:
        try:
            imgs.append(Image.open(p).convert('RGB'))
        except Exception as e:
            bad.append((p, e))
    if bad:
        for p, e in bad:
            print('⚠ 跳过无法读取的图：%s（%s）' % (os.path.basename(p), e))
    if not imgs:
        raise SystemExit('所有图片都无法读取')

    cfg = LAYOUTS[a.layout]
    gap, pad = cfg['gap'], cfg['pad']

    # 单元尺寸
    if a.unit:
        try:
            uw, uh = [int(x) for x in a.unit.lower().split('x')]
        except Exception:
            raise SystemExit('--unit 格式错误，应为 400x400')
    elif a.width:
        if a.layout == 'grid3':
            uw = (a.width - pad * 2 - 2 * gap) // 3
        elif a.layout in ('grid2', 'strip2', 'compare', 'masonry', 'hero'):
            uw = (a.width - pad * 2 - gap) // 2
        else:
            uw = a.width - pad * 2
        if uw < 40:
            raise SystemExit('--width 太小，单元宽度仅 %d px' % uw)
        ar = imgs[0].size[0] / max(1, imgs[0].size[1])
        uh = max(40, int(uw / max(0.1, ar)))
    else:
        # 按首图长宽比推导，宽 400
        ar = imgs[0].size[0] / max(1, imgs[0].size[1])
        uw = 400
        uh = max(40, int(uw / max(0.1, ar)))

    labels = {}
    if a.labels:
        if not os.path.isfile(a.labels):
            raise SystemExit('标签文件不存在：%s' % a.labels)
        with open(a.labels, 'r', encoding='utf-8') as f:
            labels = json.load(f)

    canvas, placements = build(a.layout, imgs, (uw, uh), gap, pad, labels,
                               a.unify_wb, a.fit)
    ensure_dir(a.out)
    outp = os.path.join(a.out, '合成图.png')
    if os.path.isfile(outp):
        raise SystemExit('产物已存在：%s（避免静默覆盖，请换 --out 或先删除）' % outp)
    canvas.save(outp)
    jpgp = os.path.join(a.out, '合成图.jpg')
    canvas.convert('RGB').save(jpgp, quality=94)

    with open(os.path.join(a.out, '合成报告.json'), 'w', encoding='utf-8') as f:
        json.dump({'layout': a.layout, 'n_input': len(imgs), 'unit': [uw, uh],
                   'gap': gap, 'pad': pad, 'unify_wb': a.unify_wb, 'fit': a.fit,
                   'canvas': list(canvas.size), 'placements': placements,
                   'skipped': [os.path.basename(p) for p, _ in bad]},
                  f, ensure_ascii=False, indent=2)

    print('合成完成：版式 %s' % a.layout)
    print('  输入 %d 张（跳过 %d 张）' % (len(imgs), len(bad)))
    print('  单元 %dx%d  间隙 %d  边距 %d' % (uw, uh, gap, pad))
    print('  画布 %dx%d' % canvas.size)
    print('  输出 %s' % outp)
    print('  报告 %s' % os.path.join(a.out, '合成报告.json'))


if __name__ == '__main__':
    main()
