# -*- coding: utf-8 -*-
"""拼缝与一致性检查：单元尺寸 / 间隙等宽 / 色温跳变。

用法：
  python composer_check.py --input _r/九宫格/合成图.png --layout grid3 --out _r/检查
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir, rel_lum  # noqa

CFG = {'grid3': {'cols': 3, 'gap': 12, 'pad': 12},
       'grid2': {'cols': 2, 'gap': 14, 'pad': 14},
       'strip': {'cols': 1, 'gap': 10, 'pad': 10},
       'strip2': {'cols': 2, 'gap': 12, 'pad': 12},
       'compare': {'cols': 2, 'gap': 20, 'pad': 20},
       'masonry': {'cols': 2, 'gap': 10, 'pad': 10},
       'hero': {'cols': 4, 'gap': 12, 'pad': 12}}


def unit_mean(im, box):
    x, y, w, h = box
    crop = im.crop((x, y, x + w, y + h)).resize((12, 12), 1)
    px = crop.load()
    n = 144
    r = sum(px[i, j][0] for i in range(12) for j in range(12)) // n
    g = sum(px[i, j][1] for i in range(12) for j in range(12)) // n
    b = sum(px[i, j][2] for i in range(12) for j in range(12)) // n
    return (r, g, b)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--layout', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    if not os.path.isfile(a.input):
        raise SystemExit('输入不存在：%s' % a.input)
    if a.layout not in CFG:
        raise SystemExit('未知版式：%s，可选 %s' % (a.layout, '/'.join(CFG)))

    # 读合成报告拿 placements
    rd = os.path.join(os.path.dirname(a.input), '合成报告.json')
    placements = None
    if os.path.isfile(rd):
        with open(rd, 'r', encoding='utf-8') as f:
            placements = json.load(f).get('placements')

    from PIL import Image
    im = Image.open(a.input).convert('RGB')
    W, H = im.size
    cfg = CFG[a.layout]
    issues = []

    if placements:
        # 1) 单元尺寸一致性
        sizes = {}
        for p in placements:
            x, y, w, h = p['box']
            sizes.setdefault((w, h), []).append(p['i'])
        if len(sizes) > 1 and a.layout not in ('masonry', 'hero'):
            issues.append({'rule': '单元尺寸一致', 'severity': 'high',
                           'detail': '出现 %d 种单元尺寸：%s' % (
                               len(sizes), '；'.join('%dx%d(%d个)' % (k[0], k[1], len(v))
                                                     for k, v in sizes.items())),
                           'fix': '用 --unit WxH 强制统一，或 --fit cover 裁齐'})

        # 2) 列间隙等宽
        bycol = {}
        for p in placements:
            x, y, w, h = p['box']
            bycol.setdefault(x, []).append(p)
        xs = sorted(bycol)
        if len(xs) > 1:
            gaps = [xs[i + 1] - (xs[i] + bycol[xs[i]][0]['box'][2]) for i in range(len(xs) - 1)]
            if max(gaps) - min(gaps) > 2:
                issues.append({'rule': '拼缝等宽', 'severity': 'mid',
                               'detail': '列间隙不一致：%s' % gaps,
                               'fix': '检查输入图尺寸是否一致，或统一 --unit'})

        # 3) 色温跳变
        means = [(p['i'], unit_mean(im, p['box'])) for p in placements]
        jumps = []
        for i in range(len(means) - 1):
            (ia, ca), (ib, cb) = means[i], means[i + 1]
            d = sum(abs(ca[k] - cb[k]) for k in range(3)) / 3
            jumps.append((ia, ib, round(d, 1)))
        worst = max(jumps, key=lambda t: t[2]) if jumps else None
        if worst and worst[2] > 46:
            issues.append({'rule': '色温一致', 'severity': 'mid',
                           'detail': '单元 %d 与 %d 之间平均色差 %.1f（> 46 会有明显跳变）' % worst,
                           'fix': '合成时加 --unify-wb 统一白平衡，或先统一拍摄色温'})
        elif worst and worst[2] > 30:
            issues.append({'rule': '色温一致', 'severity': 'low',
                           'detail': '单元 %d 与 %d 之间平均色差 %.1f，轻微跳变' % worst,
                           'fix': '可加 --unify-wb 进一步统一'})

        # 4) 四边留白对称
        m = cfg['pad']
        if placements:
            xs0 = [p['box'][0] for p in placements]
            ys0 = [p['box'][1] for p in placements]
            if min(xs0) != m:
                issues.append({'rule': '边距对称', 'severity': 'low',
                               'detail': '最小左边距 %d != 配置 %d' % (min(xs0), m),
                               'fix': '重跑合成时不要手工裁剪'})
            # 右/下留白
            maxr = max(p['box'][0] + p['box'][2] for p in placements)
            maxb = max(p['box'][1] + p['box'][3] for p in placements)
            if W - maxr != m or H - maxb != m:
                issues.append({'rule': '边距对称', 'severity': 'low',
                               'detail': '右/下留白为 %d/%d，配置为 %d' % (W - maxr, H - maxb, m),
                               'fix': '属正常余量，如要求严格对称可用 --width 精算'})
    else:
        issues.append({'rule': '缺少合成报告', 'severity': 'mid',
                       'detail': '同目录下没有 合成报告.json，无法做结构性校验',
                       'fix': '用 composer.py 重新合成（会自动写报告）'})

    ensure_dir(a.out)
    rep = {'input': os.path.basename(a.input), 'layout': a.layout, 'canvas': [W, H],
           'n_placed': len(placements) if placements else 0,
           'issues': issues, 'pass': len(issues) == 0}
    with open(os.path.join(a.out, '拼缝检查.json'), 'w', encoding='utf-8') as f:
        json.dump(rep, f, ensure_ascii=False, indent=2)

    L = ['# 拼缝与一致性检查', '', '输入：`%s`（版式 %s，画布 %dx%d，单元 %d 个）' % (
        rep['input'], a.layout, W, H, rep['n_placed']), '']
    if not issues:
        L.append('✅ 全部通过：单元尺寸一致、拼缝等宽、色温无明显跳变、边距对称。')
    else:
        L.append('| 规则 | 严重度 | 说明 | 修复 |')
        L.append('|---|---|---|---|')
        for i in issues:
            L.append('| %s | %s | %s | %s |' % (i['rule'], i['severity'], i['detail'], i['fix']))
    with open(os.path.join(a.out, '拼缝检查.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))

    print('拼缝检查：%s' % ('通过' if not issues else '%d 项问题' % len(issues)))
    for i in issues:
        print('  [%s] %s：%s' % (i['severity'], i['rule'], i['detail']))
    sys.exit(0 if not issues else 1)


if __name__ == '__main__':
    main()
