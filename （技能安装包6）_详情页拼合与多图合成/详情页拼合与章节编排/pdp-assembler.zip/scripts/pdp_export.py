# -*- coding: utf-8 -*-
"""详情页切图导出：把超长详情页按固定高度切成平台可接受的分段图。

用法：
  python pdp_export.py --src 详情页/详情页长图.jpg --out 切图 --slice 800
"""
import argparse
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir  # noqa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--slice', type=int, default=800, help='每段高度，默认 800')
    ap.add_argument('--idx', help='章节索引.json（提供时输出每段覆盖了哪些章节）')
    ap.add_argument('--pad-last', action='store_true', help='把最后一段补成等高（白底）')
    ap.add_argument('--format', default='jpg', choices=['jpg', 'png'])
    a = ap.parse_args()

    from PIL import Image
    if not os.path.isfile(a.src):
        raise SystemExit('源图不存在：%s' % a.src)
    if a.slice < 100:
        raise SystemExit('--slice 太小：%d（建议 >= 400）' % a.slice)

    im = Image.open(a.src).convert('RGB')
    w, h = im.size
    out = ensure_dir(a.out)

    secs = []
    if a.idx:
        if not os.path.isfile(a.idx):
            raise SystemExit('章节索引不存在：%s' % a.idx)
        with open(a.idx, 'r', encoding='utf-8') as f:
            secs = json.load(f).get('sections') or []

    n = int(math.ceil(h / float(a.slice)))
    if n <= 0:
        raise SystemExit('切图段数为 0，源图高度异常：%d' % h)

    names = []
    records = []
    for i in range(n):
        y0 = i * a.slice
        y1 = min(h, y0 + a.slice)
        seg = im.crop((0, y0, w, y1))
        if a.pad_last and seg.size[1] < a.slice:
            from PIL import Image as _I
            pad = _I.new('RGB', (w, a.slice), (255, 255, 255))
            pad.paste(seg, (0, 0))
            seg = pad
        fn = '详情页_%02d.%s' % (i + 1, a.format)
        fp = os.path.join(out, fn)
        if os.path.isfile(fp):
            raise SystemExit('产物重名：%s' % fp)
        if a.format == 'jpg':
            seg.save(fp, quality=92)
        else:
            seg.save(fp)
        names.append(fn)
        covers = [s['chapter_name'] for s in secs
                  if s['y1'] > y0 and s['y0'] < y1]
        records.append({'file': fn, 'index': i + 1, 'y0': y0, 'y1': y1,
                        'height': seg.size[1], 'covers': covers})

    dup = sorted({x for x in names if names.count(x) > 1})
    if dup:
        raise SystemExit('产物重名 %s（已阻断）' % dup)
    assert len(records) == n

    with open(os.path.join(out, '切图清单.json'), 'w', encoding='utf-8') as f:
        json.dump({'width': w, 'total_height': h, 'slice': a.slice,
                   'n_slice': n, 'records': records}, f, ensure_ascii=False, indent=2)

    L = ['# 详情页切图清单', '', '- 源图：%dx%d' % (w, h),
         '- 每段高度：%d px' % a.slice, '- 段数：%d' % n, '',
         '| # | 文件 | y 范围 | 段高 | 覆盖章节 |', '|---|---|---|---|---|']
    for r in records:
        L.append('| %d | %s | %d~%d | %d | %s |' % (
            r['index'], r['file'], r['y0'], r['y1'], r['height'],
            '、'.join(r['covers']) or '-'))
    with open(os.path.join(out, '切图清单.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))

    print('切图完成：%d 段（源 %dx%d，每段 %d）' % (n, w, h, a.slice))
    for r in records:
        print('  %-16s y=%5d~%5d  %s' % (r['file'], r['y0'], r['y1'],
                                          '、'.join(r['covers']) or '-'))
    return records


if __name__ == '__main__':
    main()
