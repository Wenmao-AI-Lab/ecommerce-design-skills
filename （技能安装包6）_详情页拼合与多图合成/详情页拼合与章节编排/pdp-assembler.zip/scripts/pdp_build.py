# -*- coding: utf-8 -*-
"""详情页拼合：按章节结构纵向拼合成一张长图。

用法：
  python pdp_build.py --template 素材清单.json
  python pdp_build.py --manifest 素材清单.json --out 详情页 --width 750
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir, get_font, hex2rgb, shade  # noqa

# 标准电商详情页章节顺序（首屏在最上，售后在最下）
STD_ORDER = [
    ('hero',        '首屏主视觉'),
    ('pain',        '痛点共鸣'),
    ('selling',     '核心卖点'),
    ('scene',       '使用场景'),
    ('model',       '模特/实拍'),
    ('detail',      '细节特写'),
    ('spec',        '规格参数'),
    ('compare',     '对比说明'),
    ('trust',       '信任背书'),
    ('service',     '售后保障'),
]

CHAPTER_KEYS = dict(STD_ORDER)


def make_template(path):
    tpl = {
        'width': 750,
        'brand_color': '#E8462D',
        'gap': 12,
        'divider': True,
        'items': [
            {'chapter': 'hero',    'title': '首屏主视觉', 'image': '素材/01_首屏.jpg'},
            {'chapter': 'pain',    'title': '痛点共鸣',   'image': '素材/02_痛点.jpg'},
            {'chapter': 'selling', 'title': '核心卖点',   'image': '素材/03_卖点.jpg'},
            {'chapter': 'scene',   'title': '使用场景',   'image': '素材/04_场景.jpg'},
            {'chapter': 'detail',  'title': '细节特写',   'image': '素材/05_细节.jpg'},
            {'chapter': 'spec',    'title': '规格参数',   'image': '素材/06_参数.jpg'},
            {'chapter': 'trust',   'title': '信任背书',   'image': '素材/07_信任.jpg'},
            {'chapter': 'service', 'title': '售后保障',   'image': '素材/08_售后.jpg'},
        ],
    }
    ensure_dir(os.path.dirname(os.path.abspath(path)) or '.')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(tpl, f, ensure_ascii=False, indent=2)
    print('已生成清单模板：%s' % path)
    print('  共 %d 个章节占位，把 image 改成你的素材路径即可' % len(tpl['items']))
    print('  可用章节键：%s' % '、'.join(k for k, _ in STD_ORDER))


def sort_items(items, keep_order):
    """按标准章节顺序排序；keep_order=True 时保持清单原顺序。

    排序稳定性：同章键的多个条目保持其在原清单中的相对先后。
    """
    if keep_order:
        return list(items)
    idx = {k: i for i, (k, _) in enumerate(STD_ORDER)}
    return sorted(items, key=lambda it: idx.get(it.get('chapter'), len(STD_ORDER)))


def load_images(items, manifest_dir, width, bg=(255, 255, 255)):
    """逐张载入并等比缩放到目标宽度，返回 [(item, pil_image, out_h), ...]。"""
    from PIL import Image
    out = []
    missing = []
    for it in items:
        rel = it.get('image') or ''
        p = rel if os.path.isabs(rel) else os.path.join(manifest_dir, rel)
        if not os.path.isfile(p):
            missing.append(rel)
            continue
        im = Image.open(p)
        # 透明素材必须垫白底，否则拼合后是黑洞
        if im.mode in ('RGBA', 'LA') or (im.mode == 'P' and 'transparency' in im.info):
            base = Image.new('RGB', im.size, bg)
            base.paste(im.convert('RGBA'), mask=im.convert('RGBA').getchannel('A'))
            im = base
        else:
            im = im.convert('RGB')
        ratio = width / float(im.size[0])
        nh = max(1, int(round(im.size[1] * ratio)))
        im = im.resize((width, nh), Image.LANCZOS)
        out.append((it, im, nh))
    if missing:
        raise SystemExit('以下章节图不存在，已阻断拼合：\n  ' +
                         '\n  '.join(missing))
    if not out:
        raise SystemExit('清单里没有可用的章节图')
    return out


def build(manifest_path, out_dir, width=None, keep_order=False, brand_color=None):
    from PIL import Image, ImageDraw
    with open(manifest_path, 'r', encoding='utf-8') as f:
        mf = json.load(f)
    items = mf.get('items') or []
    if not items:
        raise SystemExit('清单里没有 items')
    W_ = int(width or mf.get('width') or 750)
    if W_ < 200:
        raise SystemExit('目标宽度太小：%d（建议 >= 750）' % W_)
    gap = int(mf.get('gap', 12))
    use_div = bool(mf.get('divider', True))
    bc = hex2rgb(brand_color or mf.get('brand_color') or '#E8462D')
    mdir = os.path.dirname(os.path.abspath(manifest_path))

    ordered = sort_items(items, keep_order)
    loaded = load_images(ordered, mdir, W_)

    # 预计算总高：可用高度由 mf['max_height'] 控制（0 = 不限）
    max_h = int(mf.get('max_height') or 0)
    div_h = 4 if use_div else 0
    plan, cursor = [], 0
    for i, (it, im, nh) in enumerate(loaded):
        nh_eff = nh
        if max_h:
            remain = max_h - cursor - (div_h if i else 0)
            if remain <= 0:
                break
            nh_eff = min(nh, remain)
        plan.append((it, im, nh_eff, nh))
        cursor += nh_eff + (div_h if i else 0)
    if not plan:
        raise SystemExit('按当前 max_height=%d 排不下任何章节' % max_h)

    total_h = sum(p[2] for p in plan) + div_h * max(0, len(plan) - 1)
    canvas = Image.new('RGB', (W_, total_h), (255, 255, 255))
    d = ImageDraw.Draw(canvas, 'RGBA')

    idx, y = [], 0
    for i, (it, im, nh_eff, nh) in enumerate(plan):
        if i:
            if use_div:
                d.rectangle([0, y, W_, y + div_h - 1], fill=shade(bc, 1.55))
                y += div_h
        if nh_eff < nh:                      # 触发 max_height 截断
            im = im.crop((0, 0, W_, nh_eff))
        canvas.paste(im, (0, y))
        idx.append({'chapter': it.get('chapter'), 'chapter_name': CHAPTER_KEYS.get(
            it.get('chapter'), it.get('chapter') or '未分类'),
            'title': it.get('title') or '', 'y0': y, 'y1': y + nh_eff,
            'height': nh_eff, 'image': it.get('image'),
            'truncated': nh_eff < nh})
        y += nh_eff

    assert y == total_h, '内部错误：光标 %d != 总高 %d' % (y, total_h)
    outdir = ensure_dir(out_dir)
    longp = os.path.join(outdir, '详情页长图.jpg')
    if os.path.isfile(longp):
        raise SystemExit('产物已存在（防覆盖）：%s' % longp)
    canvas.save(longp, quality=92)

    with open(os.path.join(outdir, '章节索引.json'), 'w', encoding='utf-8') as f:
        json.dump({'width': W_, 'total_height': total_h, 'n_chapter': len(idx),
                   'gap': gap, 'divider': use_div, 'sections': idx},
                  f, ensure_ascii=False, indent=2)

    # 自洽校验：总高必须等于各章高度和 + 分隔条高度
    calc = sum(s['height'] for s in idx) + (4 if use_div else 0) * max(0, len(idx) - 1)
    if calc != total_h:
        raise SystemExit('总高不自洽：声明 %d，计算 %d' % (total_h, calc))

    L = ['# 详情页拼合报告', '', '- 目标宽度：%d px' % W_,
         '- 章节数：%d' % len(idx), '- 总高度：%d px' % total_h,
         '- 章节间距（分隔条）：%d px' % (4 if use_div else 0), '',
         '| # | 章节 | 标题 | 起点 y | 高度 | 占比 | 备注 |', '|---|---|---|---|---|---|---|']
    for i, s in enumerate(idx, 1):
        L.append('| %d | %s | %s | %d | %d | %.1f%% | %s |' % (
            i, s['chapter_name'], s['title'], s['y0'], s['height'],
            100.0 * s['height'] / total_h, '已截断' if s['truncated'] else ''))
    with open(os.path.join(outdir, '拼合报告.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))

    print('详情页已拼合：%s' % longp)
    print('  尺寸 %dx%d，章节 %d 个' % (W_, total_h, len(idx)))
    for s in idx:
        print('    %-10s y=%5d~%5d  h=%5d' % (s['chapter_name'], s['y0'], s['y1'], s['height']))
    return {'width': W_, 'total_height': total_h, 'sections': idx}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--template', help='生成清单模板到指定路径')
    ap.add_argument('--manifest', help='素材清单.json')
    ap.add_argument('--out', help='输出目录')
    ap.add_argument('--width', type=int)
    ap.add_argument('--brand-color')
    ap.add_argument('--keep-order', action='store_true', help='保持清单原顺序，不按标准结构排')
    a = ap.parse_args()

    if a.template:
        make_template(a.template)
        return
    if not a.manifest:
        raise SystemExit('缺少 --manifest（或用 --template 先生成模板）')
    if not os.path.isfile(a.manifest):
        raise SystemExit('清单不存在：%s' % a.manifest)
    if not a.out:
        raise SystemExit('缺少 --out')
    build(a.manifest, a.out, a.width, a.keep_order, a.brand_color)


if __name__ == '__main__':
    main()
