# -*- coding: utf-8 -*-
"""详情页自检：章节齐备 / 总高自洽 / 空白章 / 章节顺序 / 宽度合规。

用法：
  python pdp_check.py --dir 详情页 --out 检查
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir  # noqa

STD_ORDER = ['hero', 'pain', 'selling', 'scene', 'model', 'detail',
             'spec', 'compare', 'trust', 'service']
PLATFORM_WIDTHS = {750: '淘宝/天猫/拼多多', 800: '抖音小店/京东', 1242: '小红书'}


def blank_ratio(im, thr=6):
    """返回"接近纯色"的行占比 —— 用于发现视觉断层（空白章）。"""
    w, h = im.size
    px = im.load()
    step = max(1, h // 200)
    blanks = 0
    total = 0
    for y in range(0, h, step):
        c0 = px[w // 20, y]
        same = 0
        for x in range(w // 20, w, max(1, w // 20)):
            c = px[x, y]
            if max(abs(c[i] - c0[i]) for i in range(3)) <= thr:
                same += 1
            total += 1
        if same >= 15:
            blanks += 1
    return blanks / float(max(1, (h + step - 1) // step))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    from PIL import Image
    longp = os.path.join(a.dir, '详情页长图.jpg')
    if not os.path.isfile(longp):
        longp = os.path.join(a.dir, '详情页长图.png')
    if not os.path.isfile(longp):
        raise SystemExit('找不到详情页长图：%s' % a.dir)

    ip = os.path.join(a.dir, '章节索引.json')
    if not os.path.isfile(ip):
        raise SystemExit('缺少 章节索引.json，无法自检（请先跑 pdp_build.py）')
    with open(ip, 'r', encoding='utf-8') as f:
        meta = json.load(f)

    im = Image.open(longp).convert('RGB')
    w, h = im.size
    issues = []

    # 1) 实际尺寸 vs 索引声明
    if meta.get('total_height') != h:
        issues.append({'rule': '总高自洽', 'severity': 'high',
                       'detail': '索引声明总高 %s，实际图高 %d' % (meta.get('total_height'), h),
                       'fix': '索引与图不同步，重跑 pdp_build.py'})
    if meta.get('width') != w:
        issues.append({'rule': '宽度自洽', 'severity': 'high',
                       'detail': '索引声明宽 %s，实际图宽 %d' % (meta.get('width'), w),
                       'fix': '重跑 pdp_build.py'})

    secs = meta.get('sections') or []
    # 2) 各章 y 坐标必须首尾相接、从 0 起、到总高止
    if secs:
        if secs[0]['y0'] != 0:
            issues.append({'rule': '章节连续', 'severity': 'high',
                           'detail': '首章起点 %d，应为 0' % secs[0]['y0'],
                           'fix': '重跑拼合'})
        if secs[-1]['y1'] != h:
            issues.append({'rule': '章节连续', 'severity': 'high',
                           'detail': '末章终点 %d，应为总高 %d' % (secs[-1]['y1'], h),
                           'fix': '重跑拼合'})
        for i in range(1, len(secs)):
            if secs[i]['y0'] < secs[i - 1]['y1']:
                issues.append({'rule': '章节不重叠', 'severity': 'high',
                               'detail': '第 %d 章起点 %d 早于上一章终点 %d'
                                         % (i + 1, secs[i]['y0'], secs[i - 1]['y1']),
                               'fix': '重跑拼合'})
                break

    # 3) 章节顺序：已出现的标准章键必须单调递增
    keys = [s.get('chapter') for s in secs if s.get('chapter') in STD_ORDER]
    pos = [STD_ORDER.index(k) for k in keys]
    if pos != sorted(pos):
        issues.append({'rule': '章节顺序', 'severity': 'mid',
                       'detail': '标准章节顺序错乱：%s' % ' → '.join(keys),
                       'fix': '按标准结构重排，或用 --keep-order 显式接受自定义顺序'})

    # 4) 空白章（视觉断层）
    for s in secs:
        y0, y1 = s['y0'], s['y1']
        if y1 - y0 < 20:
            continue
        sub = im.crop((0, y0, w, y1))
        br = blank_ratio(sub)
        if br > 0.80:
            issues.append({'rule': '非空白章', 'severity': 'mid',
                           'detail': '章节「%s」(y=%d~%d) 近空白行占比 %.0f%%，疑似视觉断层'
                                     % (s.get('chapter_name'), y0, y1, 100 * br),
                           'fix': '检查该章素材图是否全透明/纯色，或换一张有内容的图'})

    # 5) 宽度是否符合主流平台
    if w not in PLATFORM_WIDTHS:
        issues.append({'rule': '宽度推荐', 'severity': 'low',
                       'detail': '宽 %d 不在主流详情页宽度 %s 内'
                                 % (w, '、'.join(str(k) for k in PLATFORM_WIDTHS)),
                       'fix': '淘宝/天猫用 750，抖音/京东用 800，小红书用 1242'})

    sev = {'high': 3, 'mid': 2, 'low': 1}
    top = max([sev[i['severity']] for i in issues], default=0)
    res = {'file': os.path.basename(longp), 'width': w, 'height': h,
           'n_chapter': len(secs), 'issues': issues, 'n_issue': len(issues),
           'max_severity': {3: 'high', 2: 'mid', 1: 'low', 0: 'none'}[top],
           'pass': not any(i['severity'] in ('high', 'mid') for i in issues)}

    out = ensure_dir(a.out)
    with open(os.path.join(out, '详情页自检.json'), 'w', encoding='utf-8') as f:
        json.dump(res, f, ensure_ascii=False, indent=2)

    L = ['# 详情页自检', '', '- 文件：%s' % res['file'],
         '- 尺寸：%dx%d' % (w, h), '- 章节数：%d' % len(secs),
         '- 问题数：%d（最高严重度 %s）' % (len(issues), res['max_severity']),
         '- 结论：%s' % ('✅ 通过' if res['pass'] else '❌ 需修'), '']
    for i in issues:
        L.append('- **[%s] %s**：%s → %s' % (i['severity'], i['rule'], i['detail'], i['fix']))
    with open(os.path.join(out, '详情页自检.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))

    print('详情页自检：%dx%d，章节 %d，问题 %d 项（%s）'
          % (w, h, len(secs), len(issues), res['max_severity']))
    for i in issues:
        print('  [%s] %s：%s' % (i['severity'], i['rule'], i['detail'][:76]))
    sys.exit(0 if res['pass'] else 1)


if __name__ == '__main__':
    main()
