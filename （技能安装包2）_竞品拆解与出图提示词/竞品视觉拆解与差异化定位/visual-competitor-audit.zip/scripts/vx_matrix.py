# -*- coding: utf-8 -*-
"""生成竞品视觉矩阵（md + csv）。

用法：
  python vx_matrix.py --detail _r/拆解/拆解明细.json --out _r/矩阵
"""
import argparse
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir  # noqa

DIMS = [
    ('main_color', '主色'),
    ('layout', '构图'),
    ('tone', '调性'),
    ('subject_ratio', '主体占比'),
    ('text_density', '文字密度'),
    ('saturation', '饱和度'),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--detail', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    with open(a.detail, 'r', encoding='utf-8') as f:
        data = json.load(f)

    comps = [c for c in data['competitors'] if c['images']]
    if not comps:
        raise SystemExit('没有有效竞品数据')

    # 每个竞品取第一张（主图）代表
    reps = [(c['name'], c['images'][0]) for c in comps]
    if data.get('ours'):
        reps.append(('【本方】', data['ours']))

    L = ['# 竞品视觉矩阵', '', '类目：**%s**，分析图片 **%d** 张，竞品 **%d** 个。' % (
        data.get('category') or '未指定', data['n_analyzed'], len(comps)), '']

    L.append('## 一、维度对照表（每竞品取主图）')
    L.append('')
    header = '| 对象 | ' + ' | '.join(t for _, t in DIMS) + ' |'
    L.append(header)
    L.append('|' + '---|' * (len(DIMS) + 1))
    for name, r in reps:
        vals = []
        for k, _ in DIMS:
            v = r.get(k)
            if isinstance(v, float):
                vals.append(str(v))
            else:
                vals.append(str(v))
        L.append('| %s | %s |' % (name, ' | '.join(vals)))
    L.append('')

    L.append('## 二、维度分布（竞品扎堆度）')
    L.append('')
    for k, label in DIMS:
        vals = [r.get(k) for name, r in reps if name != '【本方】']
        if not vals:
            continue
        if k in ('subject_ratio', 'text_density', 'saturation'):
            nums = [v for v in vals if isinstance(v, (int, float))]
            if not nums:
                continue
            avg = sum(nums) / len(nums)
            spread = max(nums) - min(nums)
            L.append('- **%s**：均值 %.3f，极差 %.3f，%s' % (
                label, avg, spread,
                '高度同质（极差 < 0.1）' if spread < 0.1 else ('有一定差异' if spread < 0.25 else '分歧很大')))
        else:
            cnt = Counter(vals)
            top, n = cnt.most_common(1)[0]
            share = n / len(vals)
            L.append('- **%s**：主流为「%s」（%d/%d = %.0f%%），%s' % (
                label, top, n, len(vals), share * 100,
                '扎堆严重' if share >= 0.7 else ('半数以上' if share >= 0.5 else '分散')))
    L.append('')

    # CSV
    csv = ['对象,' + ','.join(t for _, t in DIMS)]
    for name, r in reps:
        csv.append('%s,%s' % (name, ','.join(str(r.get(k, '')) for k, _ in DIMS)))
    csv_txt = '\n'.join(csv)

    ensure_dir(a.out)
    with open(os.path.join(a.out, '竞品视觉矩阵.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))
    with open(os.path.join(a.out, '竞品视觉矩阵.csv'), 'w', encoding='utf-8-sig', newline='\n') as f:
        f.write(csv_txt)

    print('竞品视觉矩阵已生成：%s' % a.out)
    print('  对象数：%d（竞品 %d + 本方 %s）' % (len(reps), len(comps), '是' if data.get('ours') else '否'))
    print('  维度数：%d' % len(DIMS))


if __name__ == '__main__':
    main()
