# -*- coding: utf-8 -*-
"""算差异化空位。

用法：
  python vx_gap.py --detail _r/拆解/拆解明细.json --out _r/空位
"""
import argparse
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir  # noqa

# 每个维度的全部可选值与"可切入"判断
CATEGORICAL = {
    'layout': ['居中', '对角', '三分', '满版', '左右分栏', '上下分栏'],
    'tone': ['亮调', '中间调', '暗调'],
}
NUMERIC = {
    'subject_ratio': ('主体占比', 0.72, '提高主体占比，让产品更"顶天立地"'),
    'text_density': ('文字密度', 0.06, '增加信息量，把核心卖点写进图里'),
    'saturation': ('饱和度', 0.65, '提高主色饱和度，视觉更抓眼'),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--detail', required=True)
    ap.add_argument('--ours')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    with open(a.detail, 'r', encoding='utf-8') as f:
        data = json.load(f)

    comps = [c for c in data['competitors'] if c['images']]
    if len(comps) < 3:
        raise SystemExit('竞品少于 3 个，空位判断不可靠。请补充竞品后重跑。')

    reps = [c['images'][0] for c in comps]
    L = ['# 差异化空位建议', '']
    L.append('基于 **%d** 个竞品的主图拆解。' % len(comps))
    L.append('')

    occupied, vacant = [], []

    for k, options in CATEGORICAL.items():
        cnt = Counter(r.get(k) for r in reps)
        n = len(reps)
        for opt in options:
            share = cnt.get(opt, 0) / n
            if share >= 0.5:
                occupied.append((k, opt, share))
            elif share <= 0.15:
                vacant.append((k, opt, cnt.get(opt, 0)))

    for k, (label, thr, advice) in NUMERIC.items():
        nums = [r.get(k) for r in reps if isinstance(r.get(k), (int, float))]
        if not nums:
            continue
        avg = sum(nums) / len(nums)
        if avg < thr:
            vacant.append((k, '高于竞品均值（%.3f）' % avg, advice))
        else:
            occupied.append((k, '已达 %.3f，竞品普遍偏高' % avg, avg))

    L.append('## 一、竞品扎堆的维度（建议避开）')
    L.append('')
    if occupied:
        L.append('| 维度 | 占有率/现状 | 说明 |')
        L.append('|---|---|---|')
        for k, opt, v in occupied:
            L.append('| %s | %s | %s |' % (k, opt, ('%.0f%% 竞品都在用' % (v * 100)) if v <= 1 else str(v)))
    else:
        L.append('无扎堆维度。')
    L.append('')

    L.append('## 二、无人占的维度（可切入）')
    L.append('')
    if vacant:
        L.append('| 维度 | 空位 | 建议动作 |')
        L.append('|---|---|---|')
        for item in vacant:
            if len(item) == 3 and isinstance(item[2], str) and not item[2].startswith('高于'):
                k, opt, advice = item
                L.append('| %s | %s | %s |' % (k, opt, advice))
            else:
                k, opt, v = item
                L.append('| %s | %s | 尝试该方向做差异化 |' % (k, opt))
    else:
        L.append('无明确空位，建议在组合上做差异（如"满版 + 亮调 + 高信息密度"）。')
    L.append('')

    # 本方距离
    if data.get('ours'):
        o = data['ours']
        L.append('## 三、本方与竞品群的中心距离')
        L.append('')
        dist = 0.0
        parts = []
        for k, options in CATEGORICAL.items():
            cnt = Counter(r.get(k) for r in reps)
            top = cnt.most_common(1)[0][0]
            d = 1.0 if o.get(k) != top else 0.0
            dist += d
            parts.append('%s：%s（竞品主流 %s）%s' % (k, o.get(k), top, '← 已差异' if d else '← 与主流重合'))
        for k, (label, thr, advice) in NUMERIC.items():
            nums = [r.get(k) for r in reps if isinstance(r.get(k), (int, float))]
            if not nums or not isinstance(o.get(k), (int, float)):
                continue
            avg = sum(nums) / len(nums)
            d = abs(o[k] - avg)
            dist += d * 5
            parts.append('%s：本方 %.3f vs 竞品均值 %.3f，差 %.3f' % (label, o[k], avg, d))
        L.append('- 综合差异分：**%.2f**（越高越有辨识度，> 2.0 为佳）' % dist)
        L.append('')
        for p in parts:
            L.append('- %s' % p)
        L.append('')
        if dist < 1.0:
            L.append('> ⚠ 本方与竞品群高度重合，建议至少在一个维度上主动拉开。')
        else:
            L.append('> ✅ 本方已具备一定辨识度，重点是把差异点在图里讲清楚。')
    else:
        L.append('## 三、本方对比')
        L.append('')
        L.append('未提供本方图片（`--ours` 或清单里的 `ours.images`），跳过差异度计算。')

    ensure_dir(a.out)
    with open(os.path.join(a.out, '差异化空位建议.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))
    with open(os.path.join(a.out, '空位数据.json'), 'w', encoding='utf-8') as f:
        json.dump({'occupied': [list(x) for x in occupied], 'vacant': [list(x) for x in vacant]},
                  f, ensure_ascii=False, indent=2, default=str)

    print('空位分析完成：%s' % os.path.join(a.out, '差异化空位建议.md'))
    print('  扎堆维度：%d 条' % len(occupied))
    print('  可切空位：%d 条' % len(vacant))
    for item in vacant[:5]:
        print('    - %s：%s' % (item[0], item[1]))


if __name__ == '__main__':
    main()
