# -*- coding: utf-8 -*-
"""竞品清单初始化与校验。

用法：
  python competitor_manifest.py --init --out 竞品/竞品清单.json
  python competitor_manifest.py --check --manifest 竞品/竞品清单.json
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir  # noqa

TEMPLATE = {
    "version": 1,
    "category": "服饰",
    "ours": {"name": "本方", "price": 169, "images": []},
    "competitors": [
        {"name": "竞品A", "price": 159, "sales": 2300, "bg": "#FFFFFF",
         "images": ["竞品A/主图1.jpg", "竞品A/主图2.jpg"], "notes": ""},
        {"name": "竞品B", "price": 189, "sales": 1200, "bg": "#FFFFFF",
         "images": ["竞品B/主图1.jpg"], "notes": ""},
    ]
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--manifest')
    ap.add_argument('--out')
    a = ap.parse_args()

    if a.init:
        out = a.out or '竞品清单.json'
        ensure_dir(os.path.dirname(os.path.abspath(out)))
        if os.path.isfile(out):
            raise SystemExit('已存在：%s（如需覆盖请先删除）' % out)
        with open(out, 'w', encoding='utf-8') as f:
            json.dump(TEMPLATE, f, ensure_ascii=False, indent=2)
        print('已生成模板：%s' % out)
        print('请填入：竞品名称 / 价格 / 销量 / 图片相对路径（相对 --root）')
        return

    if a.check:
        if not a.manifest or not os.path.isfile(a.manifest):
            raise SystemExit('清单不存在：%s' % a.manifest)
        with open(a.manifest, 'r', encoding='utf-8') as f:
            m = json.load(f)
        root = os.path.dirname(os.path.abspath(a.manifest))
        n_missing = 0
        total = 0
        for c in m.get('competitors', []):
            for img in c.get('images', []):
                total += 1
                if not os.path.isfile(os.path.join(root, img)):
                    print('  [缺失] %s / %s' % (c['name'], img))
                    n_missing += 1
        print('竞品数：%d，图片总数：%d，缺失：%d' % (len(m.get('competitors', [])), total, n_missing))
        if len(m.get('competitors', [])) < 3:
            print('⚠ 竞品数少于 3，矩阵统计意义不足')
        if total == 0:
            raise SystemExit('没有任何图片，无法分析')
        sys.exit(1 if n_missing else 0)

    ap.print_help()


if __name__ == '__main__':
    main()
