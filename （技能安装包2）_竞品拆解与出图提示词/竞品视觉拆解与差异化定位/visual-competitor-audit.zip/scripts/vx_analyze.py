# -*- coding: utf-8 -*-
"""逐张拆解竞品图片的 6 个视觉维度。

用法：
  python vx_analyze.py --manifest 竞品/竞品清单.json --root 竞品/ --out _r/拆解
"""
import argparse
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import hex2rgb, rgb2hex, ensure_dir, rel_lum  # noqa

LAYOUTS = ['居中', '对角', '三分', '满版', '左右分栏', '上下分栏']

TRUST_WORDS = ['认证', '质检', '正品', '销量', '好评', '评价', '保障',
               '七天', '无理由', '包邮', '发票', '专利', '授权', '官方']
BENEFIT_WORDS = ['轻', '软', '暖', '透气', '耐磨', '防水', '速干', '显瘦',
                 '百搭', '加厚', '高弹', '亲肤', '抗皱', '免烫']


def analyze_image(path, bg_hint=None):
    from PIL import Image
    im = Image.open(path).convert('RGB')
    w, h = im.size
    px = im.load()

    # --- 背景
    corners = [px[2, 2], px[w - 3, 2], px[2, h - 3], px[w - 3, h - 3]]
    bg = tuple(sum(c[i] for c in corners) // 4 for i in range(3))
    bg_hex = rgb2hex(bg)

    # --- 主色（排除背景）
    buckets = Counter()
    step = max(1, min(w, h) // 160)
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) < 70:
                continue
            buckets[(r // 16 * 16, g // 16 * 16, b // 16 * 16)] += 1
    tot = sum(buckets.values()) or 1
    top = buckets.most_common(3)
    main_hex = rgb2hex(top[0][0]) if top else '#CCCCCC'
    mr, mg, mb = top[0][0] if top else (204, 204, 204)
    mx, mn = max(mr, mg, mb), min(mr, mg, mb)
    sat = 0.0 if mx == 0 else round((mx - mn) / mx, 3)
    if top:
        lum = rel_lum(top[0][0])
        tone = '亮调' if lum > 0.5 else ('中间调' if lum > 0.2 else '暗调')
    else:
        tone = '未知'

    # --- 主体占比（非背景像素比例）
    nb = 0
    tt = 0
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            tt += 1
            if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) >= 70:
                nb += 1
    subject_ratio = round(nb / max(1, tt), 3)

    # --- 构图：用内容包围盒 + 质心 + 边缘填充度综合判定
    xs, ys = [], []
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) >= 70:
                xs.append(x / w)
                ys.append(y / h)
    if xs:
        cx, cy = sum(xs) / len(xs), sum(ys) / len(ys)
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        bw, bh = x1 - x0, y1 - y0
        # 边缘填充度：内容触及画布四边的程度
        edge = ((x0 < 0.04) + (x1 > 0.96) + (y0 < 0.04) + (y1 > 0.96)) / 4.0

        if edge >= 0.75 and subject_ratio > 0.55:
            layout = '满版'
        elif bw > 0.62 and bh > 0.62:
            # 大块内容铺满：看质心偏离对角线与否
            layout = '对角' if abs(cx - cy) > 0.15 else '居中'
        elif bw < 0.5 and bh < 0.55:
            # 内容集中在中部
            layout = '居中' if (0.35 < cx < 0.65 and 0.3 < cy < 0.7) else '三分'
        elif bw > bh * 1.45:
            # 横向长条 → 上下分栏；居中横条则算居中
            layout = '上下分栏' if (cy < 0.42 or cy > 0.58) else '居中'
        elif bh > bw * 1.45:
            layout = '左右分栏' if (cx < 0.42 or cx > 0.58) else '居中'
        else:
            # 剩下的看质心位置
            if abs(cx - 0.5) > 0.14 or abs(cy - 0.5) > 0.14:
                layout = '三分'
            else:
                layout = '居中'
    else:
        layout = '满版'
        cx = cy = 0.5

    # --- 文字信息密度：高对比小块估算
    text_px = 0
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if lum > 235 or lum < 25:
                text_px += 1
    text_density = round(text_px / max(1, tt), 3)

    return {
        'file': os.path.basename(path),
        'size': [w, h],
        'bg': bg_hex,
        'main_color': main_hex,
        'saturation': sat,
        'tone': tone,
        'layout': layout,
        'centroid': [round(cx, 3), round(cy, 3)],
        'subject_ratio': subject_ratio,
        'text_density': text_density,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', required=True)
    ap.add_argument('--root', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    with open(a.manifest, 'r', encoding='utf-8') as f:
        m = json.load(f)

    detail = []
    n_analyzed = 0
    for c in m.get('competitors', []):
        rows = []
        for img in c.get('images', []):
            p = os.path.join(a.root, img)
            if not os.path.isfile(p):
                continue
            r = analyze_image(p)
            r['competitor'] = c['name']
            rows.append(r)
            n_analyzed += 1
        detail.append({'name': c['name'], 'price': c.get('price'), 'sales': c.get('sales'),
                       'n_image': len(rows), 'images': rows})

    ours = None
    if m.get('ours', {}).get('images'):
        oimg = m['ours']['images'][0]
        op = os.path.join(a.root, oimg)
        if os.path.isfile(op):
            ours = analyze_image(op)

    # 竞品图片必须至少有一张可用，否则整个分析无意义（本方图不能顶替）
    n_comp_imgs = sum(len(c['images']) for c in detail)
    if n_comp_imgs == 0:
        raise SystemExit('竞品图片一张都没找到（已检查 %d 个竞品）。请核对 --root 与清单里的相对路径。'
                         % len(detail))
    n_analyzed = n_comp_imgs + (1 if ours else 0)

    ensure_dir(a.out)
    out = {'category': m.get('category'), 'n_analyzed': n_analyzed,
           'n_competitor_images': n_comp_imgs, 'competitors': detail, 'ours': ours}
    with open(os.path.join(a.out, '拆解明细.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print('已分析图片数：%d（竞品图 %d 张，覆盖 %d 个竞品；本方 %s）' % (
        n_analyzed, n_comp_imgs, len(detail), '有' if ours else '无'))
    print('%-10s %-4s %-9s %-8s %-9s %-8s %-8s' % ('竞品', '张', '主色', '构图', '主体占比', '文字密度', '调性'))
    for d in detail:
        if not d['images']:
            print('%-10s %-4d (无有效图片)' % (d['name'], 0))
            continue
        r = d['images'][0]
        print('%-10s %-4d %-9s %-8s %-9s %-8s %-8s' % (
            d['name'], d['n_image'], r['main_color'], r['layout'],
            r['subject_ratio'], r['text_density'], r['tone']))
    if ours:
        print('%-10s %-4d %-9s %-8s %-9s %-8s %-8s' % (
            '【本方】', 1, ours['main_color'], ours['layout'],
            ours['subject_ratio'], ours['text_density'], ours['tone']))
    print('明细：%s' % os.path.join(a.out, '拆解明细.json'))


if __name__ == '__main__':
    main()
