# -*- coding: utf-8 -*-
"""参考图 → 六层结构化提示词拆解。

六层：主体 / 构图 / 光影 / 色彩 / 质感 / 镜头
用法：
  python reverse_prompt.py --image 参考图.jpg --category 服饰 --out _r/反推
  python reverse_prompt.py --image a.jpg --ignore-bg --out _r/反推
"""
import argparse
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import hex2rgb, rgb2hex, ensure_dir, rel_lum  # noqa

CATEGORY_HINTS = {
    '服饰': {'主体': 'garment / apparel', 'qualities': ['垂坠感', '面料纹理', '缝线细节'],
             'neg': ['extra limbs', 'warped fabric', 'wrong logo']},
    '美妆': {'主体': 'cosmetic product', 'qualities': ['瓶身反光', '膏体质感', '标签清晰'],
             'neg': ['deformed cap', 'smudged label', 'unrealistic skin']},
    '家居': {'主体': 'homeware', 'qualities': ['材质肌理', '空间透视', '自然光'],
             'neg': ['floating object', 'wrong scale', 'cluttered']},
    '食品': {'主体': 'food product', 'qualities': ['新鲜度', '汁水质感', '摆盘'],
             'neg': ['plastic look', 'unnatural color', 'dirty plate']},
    '数码': {'主体': 'electronic device', 'qualities': ['金属拉丝', '屏幕反光', '接口细节'],
             'neg': ['bent port', 'fake screen', 'garbled text']},
    '通用': {'主体': 'product', 'qualities': ['材质表现', '细节锐度', '立体感'],
             'neg': ['blurry', 'watermark', 'text artifacts']},
}


def analyze(path, ignore_bg=False):
    from PIL import Image
    im = Image.open(path).convert('RGB')
    w, h = im.size
    px = im.load()

    corners = [px[2, 2], px[w - 3, 2], px[2, h - 3], px[w - 3, h - 3]]
    bg = tuple(sum(c[i] for c in corners) // 4 for i in range(3))
    bg_lum = rel_lum(bg)

    # ---- 色彩层
    buckets = Counter()
    step = max(1, min(w, h) // 180)
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            if ignore_bg and abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) < 70:
                continue
            buckets[(r // 16 * 16, g // 16 * 16, b // 16 * 16)] += 1
    tot = sum(buckets.values()) or 1
    palette = [(rgb2hex(c), round(n / tot * 100, 1)) for c, n in buckets.most_common(5)]
    main = hex2rgb(palette[0][0]) if palette else (128, 128, 128)
    mx, mn = max(main), min(main)
    sat = 0.0 if mx == 0 else round((mx - mn) / mx, 2)
    main_lum = rel_lum(main)

    # ---- 构图层
    fg = 0
    xs, ys = [], []
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) >= 70:
                fg += 1
                xs.append(x / w)
                ys.append(y / h)
    nb = max(1, (w // step) * (h // step))
    subject_ratio = round(fg / nb, 3)
    if xs:
        cx, cy = sum(xs) / len(xs), sum(ys) / len(ys)
    else:
        cx = cy = 0.5
    # 景别粗略判定
    if subject_ratio > 0.62:
        shot = 'close-up'
    elif subject_ratio > 0.32:
        shot = 'medium shot'
    else:
        shot = 'wide shot'
    # 三分法位置
    hp = 'center'
    if cx < 0.4:
        hp = 'left third'
    elif cx > 0.6:
        hp = 'right third'
    vp = 'center'
    if cy < 0.4:
        vp = 'upper third'
    elif cy > 0.6:
        vp = 'lower third'

    # ---- 光影层：按四象限亮度差判方向
    quads = {'左上': 0, '右上': 0, '左下': 0, '右下': 0}
    cnts = {k: 0 for k in quads}
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            k = ('左上' if y < h / 2 else '左下') if x < w / 2 else ('右上' if y < h / 2 else '右下')
            quads[k] += 0.2126 * r + 0.7152 * g + 0.0722 * b
            cnts[k] += 1
    for k in quads:
        quads[k] /= max(1, cnts[k])
    bright = max(quads, key=quads.get)
    dark = min(quads, key=quads.get)
    contrast_ratio = round(max(quads.values()) / max(1e-6, min(quads.values())), 2)
    hard = 'hard light, sharp shadow' if contrast_ratio > 1.35 else (
        'soft light, diffuse shadow' if contrast_ratio < 1.12 else 'medium-contrast light')
    src_dir = {'左上': 'light from top-left', '右上': 'light from top-right',
               '左下': 'light from bottom-left', '右下': 'light from bottom-right'}[bright]

    # ---- 背景
    bg_type = 'clean seamless backdrop' if bg_lum > 0.75 else (
        'dark studio backdrop' if bg_lum < 0.2 else 'mid-tone backdrop')

    return {
        'file': os.path.basename(path),
        'size': [w, h],
        'layers': {
            '主体': {
                'subject_coverage': subject_ratio,
                'note': '主体占画面 %.1f%%' % (subject_ratio * 100),
                'prompt': 'single product as hero subject, occupying about %d%% of frame' % int(subject_ratio * 100),
            },
            '构图': {
                'shot': shot, 'h_position': hp, 'v_position': vp,
                'orientation': 'square' if abs(w / h - 1) < 0.05 else ('portrait' if h > w else 'landscape'),
                'prompt': '%s, subject placed %s / %s, %s composition' % (
                    shot, hp, vp, 'square' if abs(w / h - 1) < 0.05 else ('vertical' if h > w else 'horizontal')),
            },
            '光影': {
                'brightest_quadrant': bright, 'darkest_quadrant': dark,
                'contrast_ratio': contrast_ratio, 'quality': hard,
                'prompt': '%s, %s' % (src_dir, hard),
            },
            '色彩': {
                'palette': palette, 'main_color': palette[0][0] if palette else '#808080',
                'saturation': sat,
                'tone': 'bright' if main_lum > 0.5 else ('mid-tone' if main_lum > 0.2 else 'dark'),
                'bg_type': bg_type,
                'prompt': 'primary color %s, saturation %.2f, %s, %s' % (
                    palette[0][0] if palette else '#808080', sat,
                    'bright key' if main_lum > 0.5 else ('mid key' if main_lum > 0.2 else 'low key'), bg_type),
            },
            '质感': {
                'qualities': CATEGORY_HINTS['通用']['qualities'],
                'note': '需在提示词里显式声明材质关键词，否则模型会自行发挥',
                'prompt': 'crisp material detail, visible texture, sharp edges, high micro-contrast',
            },
            '镜头': {
                'depth': 'shallow depth of field' if subject_ratio > 0.4 else 'deep focus',
                'sharpness': 'tack sharp on subject',
                'prompt': 'commercial product photography, 85mm equivalent, F5.6, tack sharp on subject, '
                          'sub-pixel clean edges',
            },
        },
        'bg_detected': rgb2hex(bg),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--image', required=True)
    ap.add_argument('--category', default='通用')
    ap.add_argument('--ignore-bg', action='store_true')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    if not os.path.isfile(a.image):
        raise SystemExit('参考图不存在：%s' % a.image)
    if a.category not in CATEGORY_HINTS:
        raise SystemExit('未知品类：%s，可选 %s' % (a.category, '/'.join(CATEGORY_HINTS)))

    res = analyze(a.image, a.ignore_bg)
    hint = CATEGORY_HINTS[a.category]
    res['category'] = a.category
    res['layers']['主体']['prompt'] = '%s, %s' % (hint['主体'], res['layers']['主体']['prompt'])
    res['layers']['质感']['qualities'] = hint['qualities']
    res['negative'] = hint['neg']

    ensure_dir(a.out)
    with open(os.path.join(a.out, '反推结果.json'), 'w', encoding='utf-8') as f:
        json.dump(res, f, ensure_ascii=False, indent=2)

    L = ['# 提示词反推结果', '', '参考图：`%s`（%dx%d）' % (res['file'], res['size'][0], res['size'][1]),
         '品类：**%s**' % a.category, '', '| 层 | 关键值 | 可拼进提示词的短语 |', '|---|---|---|']
    for name, d in res['layers'].items():
        keys = []
        for k, v in d.items():
            if k == 'prompt':
                continue
            keys.append('%s=%s' % (k, v if not isinstance(v, list) else '、'.join(str(x) for x in v[:3])))
        L.append('| %s | %s | `%s` |' % (name, '；'.join(keys), d['prompt']))
    L.append('')
    L.append('## 负向提示词（品类默认）')
    L.append('')
    for n in res['negative']:
        L.append('- `%s`' % n)
    with open(os.path.join(a.out, '反推结果.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))

    print('反推完成：%s' % res['file'])
    print('  识别背景：%s  主体占比 %.1f%%' % (res['bg_detected'], res['layers']['主体']['subject_coverage'] * 100))
    print('  构图：%s / %s / %s' % (res['layers']['构图']['shot'],
                                    res['layers']['构图']['h_position'], res['layers']['构图']['v_position']))
    print('  光影：%s（对比比 %.2f）' % (res['layers']['光影']['quality'], res['layers']['光影']['contrast_ratio']))
    print('  主色：%s  饱和度 %.2f  调性 %s' % (res['layers']['色彩']['main_color'],
                                                res['layers']['色彩']['saturation'], res['layers']['色彩']['tone']))
    print('输出：%s' % a.out)


if __name__ == '__main__':
    main()
