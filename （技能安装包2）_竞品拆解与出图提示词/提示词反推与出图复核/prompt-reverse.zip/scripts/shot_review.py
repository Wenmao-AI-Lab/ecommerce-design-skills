# -*- coding: utf-8 -*-
"""出图结果 vs 参考图 六层逐项复核。

用法：
  python shot_review.py --reference 参考图.jpg --result 出图/*.jpg --out _r/复核
  python shot_review.py --reference a.jpg --dir 出图/ --out _r/复核
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir, hex2rgb  # noqa

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reverse_prompt import analyze  # noqa

# 每层容差
TOL = {
    '主体': {'subject_coverage': 0.18},
    '构图': {'shot': 0, 'h_position': 0, 'v_position': 0},
    '光影': {'quality': 0, 'contrast_ratio': 0.22},
    '色彩': {'main_color': 60, 'saturation': 0.20, 'tone': 0},
    '质感': {},
    '镜头': {'depth': 0},
}

SEV = {'低': 1, '中': 2, '高': 3}


def color_dist(a, b):
    ra, ga, ba = hex2rgb(a)
    rb, gb, bb = hex2rgb(b)
    return round((((ra - rb) ** 2 + (ga - gb) ** 2 + (ba - bb) ** 2) ** 0.5) / 4.42, 1)


ADVICE = {
    ('光影', 'quality'): '提示词里明确光源方向与软硬，照抄参考图：{ref}',
    ('光影', 'contrast_ratio'): '光比差 {delta}，加大/减小光比关键词（如 dramatic shadow / soft fill light）',
    ('色彩', 'main_color'): '主色偏了，提示词首位加上主色 hex：{ref}',
    ('色彩', 'saturation'): '饱和度差 {delta}，调整 vivid / muted / desaturated 关键词',
    ('构图', 'shot'): '景别不对，把「{ref}」写进提示词开头',
    ('构图', 'h_position'): '主体水平位不对，加「{ref}」placement',
    ('构图', 'v_position'): '主体垂直位不对，加「{ref}」placement',
    ('主体', 'subject_coverage'): '主体占比差 {delta}，加「occupying about {ref_pct}% of frame」',
}


def fill(tpl, d):
    """安全的模板填充：只替换已知占位，绝不让 %.2f / %d 之类的裸格式符漏给用户。"""
    s = tpl
    ref = d['ref']
    ref_pct = int(ref * 100) if isinstance(ref, (int, float)) else ref
    return (s.replace('{ref_pct}', str(ref_pct))
             .replace('{ref}', str(ref))
             .replace('{delta}', str(d['delta']))
             .replace('{got}', str(d['got'])))


def review(ref, res, name):
    diffs = []
    for layer, keys in TOL.items():
        a = ref['layers'].get(layer, {})
        b = res['layers'].get(layer, {})
        for k, tol in keys.items():
            va, vb = a.get(k), b.get(k)
            if va is None or vb is None:
                continue
            if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
                d = abs(va - vb)
                if d <= tol:
                    continue
                sev = '高' if d > tol * 2 else '中'
                rec = {'ref': va, 'got': vb, 'delta': round(d, 3)}
                tpl = ADVICE.get((layer, k))
                adv = fill(tpl, rec) if tpl else '调整 %s（参考 %s → 出图 %s）' % (k, va, vb)
                diffs.append({'layer': layer, 'key': k, 'ref': va, 'got': vb,
                              'delta': round(d, 3), 'tol': tol, 'severity': sev, 'advice': adv})
            else:
                if va != vb:
                    adv = ('提示词里显式写 %s：%s' % (k, va)) if not ADVICE.get((layer, k)) \
                        else fill(ADVICE[(layer, k)], {'ref': va, 'got': vb, 'delta': None})
                    diffs.append({'layer': layer, 'key': k, 'ref': va, 'got': vb,
                                  'delta': None, 'tol': tol, 'severity': '中',
                                  'advice': adv})
        if layer == '色彩':
            pa = a.get('main_color')
            pb = b.get('main_color')
            if pa and pb:
                cd = color_dist(pa, pb)
                if cd > 20:
                    diffs.append({'layer': '色彩', 'key': 'palette_distance', 'ref': pa, 'got': pb,
                                  'delta': cd, 'tol': 20, 'severity': '高' if cd > 35 else '中',
                                  'advice': '主色色距 %.1f，把 %s 直接写进提示词' % (cd, pa)})

    top = max([SEV[d['severity']] for d in diffs], default=0)
    return {
        'file': name,
        'size': res['size'],
        'n_diff': len(diffs),
        'max_severity': {3: '高', 2: '中', 1: '低', 0: '无'}[top],
        'diffs': diffs,
        'pass': top < SEV['高'],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--reference', required=True)
    ap.add_argument('--result', nargs='*')
    ap.add_argument('--dir')
    ap.add_argument('--category', default='通用')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    if not os.path.isfile(a.reference):
        raise SystemExit('参考图不存在：%s' % a.reference)

    files = list(a.result or [])
    if a.dir:
        for n in sorted(os.listdir(a.dir)):
            if n.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                files.append(os.path.join(a.dir, n))
    files = [f for f in files if os.path.isfile(f)]
    if not files:
        raise SystemExit('没有待复核的出图：给 --result 或 --dir')

    ref = analyze(a.reference, True)
    results = []
    for p in files:
        res = analyze(p, True)
        results.append(review(ref, res, os.path.basename(p)))

    assert len(results) > 0
    ensure_dir(a.out)
    with open(os.path.join(a.out, '复核报告.json'), 'w', encoding='utf-8') as f:
        json.dump({'reference': os.path.basename(a.reference),
                   'n': len(results), 'results': results}, f, ensure_ascii=False, indent=2)

    L = ['# 出图复核报告', '', '参考图：`%s`' % os.path.basename(a.reference), '',
         '共复核 **%d** 张。' % len(results), '',
         '| 出图 | 尺寸 | 差异项 | 最高严重度 | 结论 |', '|---|---|---|---|---|']
    for r in results:
        L.append('| %s | %dx%d | %d | %s | %s |' % (
            r['file'], r['size'][0], r['size'][1], r['n_diff'], r['max_severity'],
            '✅ 通过' if r['pass'] else '❌ 需重出'))
    L.append('')
    for r in results:
        if not r['diffs']:
            continue
        L.append('## %s' % r['file'])
        L.append('')
        L.append('| 层 | 项 | 参考 | 出图 | 偏差 | 容差 | 严重度 |')
        L.append('|---|---|---|---|---|---|---|')
        for d in r['diffs']:
            L.append('| %s | %s | %s | %s | %s | %s | %s |' % (
                d['layer'], d['key'], d['ref'], d['got'],
                '-' if d['delta'] is None else d['delta'], d['tol'], d['severity']))
        L.append('')
        L.append('**改词建议：**')
        L.append('')
        for d in r['diffs']:
            L.append('- [%s] %s：%s' % (d['severity'], d['layer'], d['advice']))
        L.append('')

    with open(os.path.join(a.out, '复核报告.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))

    npass = sum(1 for r in results if r['pass'])
    print('复核完成：通过 %d / %d' % (npass, len(results)))
    for r in results:
        print('  %-24s %s  差异 %d 项  最高 %s' % (
            r['file'], 'PASS' if r['pass'] else 'FAIL', r['n_diff'], r['max_severity']))
    sys.exit(0 if npass == len(results) else 1)


if __name__ == '__main__':
    main()
