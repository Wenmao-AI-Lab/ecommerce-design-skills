# -*- coding: utf-8 -*-
"""六层拆解 → 正向/负向提示词 + 参数建议。

用法：
  python prompt_builder.py --reverse _r/反推/反推结果.json --style 电商主图 --platform taobao --out _r/提示词
  python prompt_builder.py --reverse ... --layers 主体,构图,光影 --out _r/提示词
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ensure_dir, PLATFORMS  # noqa

STYLES = {
    '电商主图': {'prefix': 'commercial e-commerce main image, clean and premium',
                'suffix': 'high conversion visual, clean composition, platform compliant, no text overlay'},
    '场景图': {'prefix': 'lifestyle scene photography, in-use context',
              'suffix': 'natural ambience, believable environment, product clearly readable'},
    '细节图': {'prefix': 'macro detail shot, extreme close-up on texture',
              'suffix': 'razor sharp micro detail, even lighting, no distracting background'},
    '对比图': {'prefix': 'side-by-side comparison layout, before and after',
              'suffix': 'consistent lighting across both sides, clear visual distinction'},
}

BASE_NEG = ['text', 'watermark', 'logo artifacts', 'blurry', 'low resolution',
            'oversaturated', 'jpeg artifacts', 'deformed', 'duplicate subject',
            'extra objects', 'cropped subject', 'cluttered background']

PARAMS = {
    '淘宝/天猫': {'width': 800, 'height': 800, 'ratio': '1:1', 'steps': [24, 32], 'cfg': [5.5, 7.5]},
    '京东': {'width': 800, 'height': 800, 'ratio': '1:1', 'steps': [24, 32], 'cfg': [6.0, 7.5]},
    '拼多多': {'width': 800, 'height': 800, 'ratio': '1:1', 'steps': [20, 30], 'cfg': [5.5, 7.0]},
    '抖音小店': {'width': 800, 'height': 800, 'ratio': '1:1', 'steps': [24, 32], 'cfg': [6.0, 7.5]},
    '小红书': {'width': 1242, 'height': 1660, 'ratio': '3:4', 'steps': [26, 36], 'cfg': [6.0, 8.0]},
}


def build(rev, style, platform, layers):
    L = rev['layers']
    parts = [STYLES[style]['prefix']]
    for name in layers:
        if name in L:
            parts.append(L[name]['prompt'])
    parts.append(STYLES[style]['suffix'])
    positive = ', '.join(parts)

    neg = list(BASE_NEG)
    for n in rev.get('negative', []):
        if n not in neg:
            neg.append(n)
    negative = ', '.join(neg)

    pname = None
    for k, v in PLATFORMS.items():
        if k == platform or v['name'] == platform:
            pname = v['name']
            break
    if pname is None:
        for k, v in PARAMS.items():
            if k == platform:
                pname = k
                break
    params = PARAMS.get(pname) or PARAMS['淘宝/天猫']

    # 从六层里抽可执行要点
    checks = []
    sc = L.get('主体', {}).get('subject_coverage')
    if sc is not None:
        checks.append('主体占画面约 %d%%（参考图实测 %.1f%%）' % (int(sc * 100), sc * 100))
    if '光影' in L:
        checks.append('光影：%s' % L['光影']['quality'])
    if '色彩' in L:
        checks.append('主色 %s，饱和度 %.2f' % (L['色彩']['main_color'], L['色彩']['saturation']))
    if '构图' in L:
        checks.append('构图：%s / %s' % (L['构图']['shot'], L['构图']['h_position']))

    return {'positive': positive, 'negative': negative, 'params': params,
            'style': style, 'platform': pname or platform, 'layers_used': layers,
            'check_points': checks}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--reverse', required=True)
    ap.add_argument('--style', default='电商主图', choices=sorted(STYLES))
    ap.add_argument('--platform', default='taobao')
    ap.add_argument('--layers', default='主体,构图,光影,色彩,质感,镜头')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    with open(a.reverse, 'r', encoding='utf-8') as f:
        rev = json.load(f)

    layers = [x.strip() for x in a.layers.split(',') if x.strip()]
    valid = [x for x in layers if x in rev['layers']]
    if not valid:
        raise SystemExit('--layers 里没有有效层名，可选：%s' % '/'.join(rev['layers']))
    dropped = [x for x in layers if x not in rev['layers']]
    if dropped:
        print('⚠ 忽略无效层：%s' % '、'.join(dropped))

    r = build(rev, a.style, a.platform, valid)
    ensure_dir(a.out)

    pp = os.path.join(a.out, '正向提示词.txt')
    np_ = os.path.join(a.out, '负向提示词.txt')
    sp = os.path.join(a.out, '参数建议.json')
    with open(pp, 'w', encoding='utf-8', newline='\n') as f:
        f.write(r['positive'] + '\n')
    with open(np_, 'w', encoding='utf-8', newline='\n') as f:
        f.write(r['negative'] + '\n')
    with open(sp, 'w', encoding='utf-8') as f:
        json.dump({'style': r['style'], 'platform': r['platform'], 'params': r['params'],
                   'layers_used': r['layers_used'], 'check_points': r['check_points']},
                  f, ensure_ascii=False, indent=2)

    # 提示词长度守卫：过长会超模型输入上限
    n_chars = len(r['positive'])
    warn = ''
    if n_chars > 1200:
        warn = '  ⚠ 过长，建议用 --layers 精简'
    print('提示词已生成：%s' % a.out)
    print('  风格：%s  平台：%s  用层：%s' % (r['style'], r['platform'], '/'.join(valid)))
    print('  正向 %d 字，负向 %d 字%s' % (len(r['positive']), len(r['negative']), warn))
    print('  尺寸：%dx%d（%s）  步数 %s  CFG %s' % (
        r['params']['width'], r['params']['height'], r['params']['ratio'],
        r['params']['steps'], r['params']['cfg']))
    print()
    print('【正向提示词】')
    print(r['positive'])


if __name__ == '__main__':
    main()
