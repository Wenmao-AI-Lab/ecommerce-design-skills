# -*- coding: utf-8 -*-
"""公共工具：字体、目录、平台尺寸、色值、文本换行。纯标准库 + Pillow。

被本技能所有脚本共用。不依赖网络、不依赖 numpy。
"""
import os
import re

try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except Exception:
    Image = ImageDraw = ImageFont = None
    HAS_PIL = False

# ---------------------------------------------------------------- 平台尺寸
PLATFORMS = {
    'taobao':   {'name': '淘宝/天猫', 'main': (800, 800), 'detail_w': 790, 'banner': (1920, 480), 'ratio': 1.0},
    'jd':       {'name': '京东',      'main': (800, 800), 'detail_w': 790, 'banner': (1920, 500), 'ratio': 1.0},
    'pdd':      {'name': '拼多多',    'main': (800, 800), 'detail_w': 750, 'banner': (1200, 400), 'ratio': 1.0},
    'douyin':   {'name': '抖音小店',  'main': (800, 800), 'detail_w': 750, 'banner': (1200, 480), 'ratio': 1.0},
    'xiaohongshu': {'name': '小红书', 'main': (1242, 1660), 'detail_w': 750, 'banner': (1242, 500), 'ratio': 0.75},
    'kuaishou': {'name': '快手',      'main': (800, 800), 'detail_w': 750, 'banner': (1200, 400), 'ratio': 1.0},
    '1688':     {'name': '1688',      'main': (800, 800), 'detail_w': 790, 'banner': (1920, 480), 'ratio': 1.0},
}


def parse_platforms(raw, default='taobao'):
    """把 '淘宝,京东' / 'taobao' / '淘宝' 统一解析为平台 key 列表。"""
    if not raw:
        return [default]
    alias = {}
    for k, v in PLATFORMS.items():
        alias[k] = k
        alias[v['name']] = k
        alias[v['name'].split('/')[0]] = k
    out = []
    for token in re.split(r'[,，、\s]+', str(raw).strip()):
        if not token:
            continue
        key = alias.get(token) or alias.get(token.lower())
        if key and key not in out:
            out.append(key)
    return out or [default]


# ---------------------------------------------------------------- 字体
FONT_PATHS_REGULAR = [
    r'C:\Windows\Fonts\msyh.ttc',
    r'C:\Windows\Fonts\msyh.ttf',
    r'C:\Windows\Fonts\simhei.ttf',
    r'C:\Windows\Fonts\simsun.ttc',
    '/System/Library/Fonts/PingFang.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
]
FONT_PATHS_BOLD = [
    r'C:\Windows\Fonts\msyhbd.ttc',
    r'C:\Windows\Fonts\msyhbd.ttf',
    r'C:\Windows\Fonts\simhei.ttf',
    '/System/Library/Fonts/PingFang.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
]

_FONT_CACHE = {}


def find_font(bold=False):
    for p in (FONT_PATHS_BOLD if bold else FONT_PATHS_REGULAR):
        if os.path.isfile(p):
            return p
    return None


def get_font(size, bold=False):
    key = (size, bold)
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    path = find_font(bold)
    if path is None:
        f = ImageFont.load_default()
    else:
        try:
            f = ImageFont.truetype(path, size)
        except Exception:
            f = ImageFont.load_default()
    _FONT_CACHE[key] = f
    return f


# ---------------------------------------------------------------- 目录
def ensure_dir(p):
    if p and not os.path.isdir(p):
        os.makedirs(p, exist_ok=True)
    return p


def write(path, text, encoding='utf-8'):
    ensure_dir(os.path.dirname(os.path.abspath(path)))
    with open(path, 'w', encoding=encoding, newline='\n') as f:
        f.write(text)
    return path


def read(path, encoding='utf-8'):
    with open(path, 'r', encoding=encoding, errors='replace') as f:
        return f.read()


def scan_placeholders(root):
    """列出目录下所有文件（相对路径），用于自检。"""
    out = []
    for dp, dn, fn in os.walk(root):
        for f in fn:
            out.append(os.path.relpath(os.path.join(dp, f), root))
    return sorted(out)


# ---------------------------------------------------------------- 色值
def hex2rgb(h):
    h = str(h).strip().lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb2hex(rgb):
    return '#%02X%02X%02X' % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def rgb2cmyk(rgb):
    r, g, b = [v / 255.0 for v in rgb]
    k = 1 - max(r, g, b)
    if k >= 1:
        return (0.0, 0.0, 0.0, 100.0)
    c = (1 - r - k) / (1 - k)
    m = (1 - g - k) / (1 - k)
    y = (1 - b - k) / (1 - k)
    return tuple(round(v * 100, 1) for v in (c, m, y, k))


def shade(rgb, factor):
    """factor<1 变暗，>1 变亮（向白靠拢）。

    **必须返回 int 元组** —— PIL 的 Image.new / putpixel 只接受整数色值，
    早期版本返回 float 导致 `TypeError: 'float' object cannot be interpreted as an integer`。
    """
    if factor <= 1:
        return tuple(int(max(0, min(255, v * factor))) for v in rgb)
    t = min(1.0, factor - 1)
    return tuple(int(max(0, min(255, v + (255 - v) * t))) for v in rgb)


def rel_lum(rgb):
    def ch(v):
        v = v / 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = [ch(v) for v in rgb[:3]]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = rel_lum(a), rel_lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return round((hi + 0.05) / (lo + 0.05), 2)


def pick_text_on(bg, candidates=None):
    """给定底色，返回可读性最好的文字色（默认在纯白与近黑之间挑）。

    修复要点（对应方法论坑 8「选色函数在暖色底上选错字色」）：
    早期用 contrast(白, bg) < contrast(#1A1A1A, bg) 判定。在高饱和暖色底
    （如品牌色 #E8462D：白字 3.93:1、深字 4.36:1）上**两边都不达标**，
    函数仍返回白字，调用方以为"已选到可读色"直接出图 —— 过不了检。

    判定顺序（先品牌观感、后数值）：
      ① 白字能达标（>= 4.5）           -> 用白字（深底/品牌底的主流做法）
      ② 深字能达标                     -> 用深字（浅底的主流做法）
      ③ 两边都不达标 -> 返回**对比度更高**的那个，由调用方配合 safe_pair()
         调整底色，而不是在这里盲选。
    这样既保住"橙底白字"的品牌观感，也不会在浅底上错误地选白字。
    """
    white, dark = (255, 255, 255), (26, 26, 26)
    if candidates is None:
        if contrast(white, bg) >= 4.5:
            return white
        if contrast(dark, bg) >= 4.5:
            return dark
        return max((white, dark), key=lambda c: contrast(c, bg))
    return max(candidates, key=lambda c: contrast(c, bg))


def readable_on(bg, want=(255, 255, 255), min_ratio=4.5):
    """返回一个「在 bg 上至少达到 min_ratio 对比度」的文字色。

    优先保留 want 的色相（白字就保白），不达标时按需加深底色方向调整 ——
    但**不返回发灰的"半黑半白"**，而是直接在 want 与纯黑/纯白之间取能达标的最亮值。
    这样贴片/角标上的文字既不刺眼也不会不可读。
    """
    def c(fg):
        return contrast(fg, bg)
    if c(want) >= min_ratio:
        return want
    # 调低 want 的亮度（白字 -> 逐步变暗；黑字 -> 逐步变亮）
    is_white = sum(want) / 3 > 127
    best = want
    best_ratio = c(want)
    for step in range(1, 51):
        t = step / 50.0
        if is_white:
            cand = tuple(int(v + (0 - v) * t) for v in want)
        else:
            cand = tuple(int(v + (255 - v) * t) for v in want)
        r = c(cand)
        if r >= min_ratio:
            return cand
        if r > best_ratio:
            best, best_ratio = cand, r
    return best


def readable_bg(base, text_color=(255, 255, 255), min_ratio=4.5, prefer_bg=None):
    """返回一个「让 text_color 达标」的底色：从 base 出发只调暗（保色相）。

    修复要点（对应方法论坑 7「选色函数与底色来源不同步」）：
    早期实现不管 base 能不能承载 text_color，先按「调暗 base」硬走一遍，
    在浅底（如 #FBE3DF）上会一路调到几乎全黑才算达标 —— 图能过检但视觉被毁。
    现在改成三级降级，且优先复用 pick_text_on(base) 选中的文字色：

      ① base 本身达标            -> 原样返回（浅底配深字走这条）
      ② 调暗 base 后能达到        -> 返回满足条件的最亮者（保色相，视觉损失最小）
      ③ 调暗也达不到             -> 才退回到纯黑

    这样「浅底+深字」与「深底+白字」两种版式都能拿到色相正确、对比度达标的组合。
    """
    if text_color is None:
        text_color = pick_text_on(base)
    if contrast(text_color, base) >= min_ratio:
        return base
    for step in range(1, 61):
        t = step / 60.0
        cand = tuple(int(v * (1 - t * 0.92)) for v in base)
        if contrast(text_color, cand) >= min_ratio:
            return cand
    # 调暗到底仍不达标 —— 交给调用方换文字色，而不是把底压成黑色
    return (0, 0, 0)


def _on_dark(ink):
    """判断 ink 是否是"给深底用的浅色墨"。"""
    return sum(ink) / 3.0 > 127


def safe_pair(base, text_color=None, min_ratio=4.5, darkest=None, lightest=None):
    """返回 (底色, 文字色)，保证两者对比度 >= min_ratio，**且尽量保留品牌色相**。

    修复要点（对应方法论坑 9「达标 ≠ 好看：把品牌底压成纯黑」）：
    最初版本三级降级里最后一步直接返回纯黑底 + 纯白字，结果**所有橙色贴片全变黑图** ——
    对比度 21:1 满分，但品牌色 0 分，贴片在直播间里彻底失去辨识度。
    现在改为：只在 base 自身的**色相带**内做明度位移

      · 白字配底  -> 把 base 压暗（sim 到 darkest，默认亮度 0.45，仍是深橙而非黑）
      · 深字配底  -> 把 base 提亮（sim 到 lightest，默认亮度 1.75，仍是浅橙而非白）
      · 实在压不到 -> 才允许越过 darkest/lightest 继续推，但**永不退化成纯黑/纯白**

    这样既满足 4.5:1，又让贴片保持"番茄红/橙"的品牌观感。
    """
    tc = text_color
    if tc is None:
        tc = pick_text_on(base)
    dark_ink = not _on_dark(tc)          # 文字是深色 -> 底要变浅
    lim = (lightest if dark_ink else darkest)
    if lim is None:
        lim = 1.75 if dark_ink else 0.45

    def cand_at(sim):
        return shade(base, sim)

    if contrast(tc, base) >= min_ratio:
        return base, tc

    # ① 在限幅内找（保品牌观感的理想区间）
    lo, hi = (1.0, lim) if dark_ink else (lim, 1.0)
    best, best_cr = base, contrast(tc, base)
    for i in range(0, 121):
        sim = lo + (hi - lo) * i / 120.0
        c = cand_at(sim)
        cr = contrast(tc, c)
        if cr >= min_ratio:
            return c, tc
        if cr > best_cr:
            best, best_cr = c, cr

    # ② 越过限幅继续推 —— 但只在同色相明度轴上，绝不落到纯黑/纯白
    ext_lo, ext_hi = (1.0, 3.0) if dark_ink else (0.06, 1.0)
    for i in range(0, 201):
        sim = ext_lo + (ext_hi - ext_lo) * i / 200.0
        c = cand_at(sim)
        cr = contrast(tc, c)
        if cr >= min_ratio:
            return c, tc
        if cr > best_cr:
            best, best_cr = c, cr

    return best, tc



def band_shade(base, limit, dark_ink, ok, lo=0.0, hi=1.0, n=120):
    """在 base 的**同色相明度轴**上找一个满足 ok() 的颜色，尽量靠近 base。

    · dark_ink=True  -> 向亮侧走（浅底），在 base 与 limit 之间二分；
    · dark_ink=False -> 向暗侧走（深底），在 limit 与 base 之间二分。

    这是「达标 ≠ 好看」的正解：对比度是**约束**，不是目标函数。
    不要用二分找到刚好达标就返回 —— 二分返回的是区间边界上"刚好达标"的点，
    看着像精心调过，实则贴着阈值、抗锯齿一抖就掉。返回**距离 base 最近**的点，
    视觉上与 base 几乎同色，同时又稳定达标。
    """
    if ok(base):
        return base
    a, b = base, limit
    if ok(b):
        mid = b
        for _ in range(40):
            t = (lo + hi) / 2.0
            mid = shade(base, t)
            if ok(mid):
                if dark_ink:
                    hi = t          # 亮侧：还能更靠近 base
                else:
                    lo = t          # 暗侧：还能更靠近 base
            else:
                if dark_ink:
                    lo = t
                else:
                    hi = t
        best = shade(base, (lo + hi) / 2.0)
        return best if ok(best) else mid
    return b

# ---------------------------------------------------------------- 文本
def text_width(draw, s, font):
    try:
        box = draw.textbbox((0, 0), s, font=font)
        return box[2] - box[0]
    except Exception:
        return len(s) * (font.size if hasattr(font, 'size') else 14)


def wrap(draw, s, font, max_w):
    """中英混排断行：CJK 逐字断，西文按词断。"""
    if not s:
        return ['']
    out, line, buf = [], '', ''
    for ch in s:
        if ch == '\n':
            out.append(line + buf)
            line, buf = '', ''
            continue
        trial = line + buf + ch
        if text_width(draw, trial, font) <= max_w:
            buf += ch
            continue
        # 需要断行
        if ch.isascii() and ch not in ' ,.;:!?)]}':
            # 西文尽量按词断
            if buf and ' ' in buf:
                cut = buf.rstrip().rfind(' ')
                line = (line + buf[:cut]).rstrip()
                buf = buf[cut + 1:] + ch
            else:
                out.append(line + buf)
                line, buf = '', ch
        else:
            out.append(line + buf)
            line, buf = '', '' if ch == ' ' else ch
        if text_width(draw, line + buf, font) > max_w and line:
            out.append(line)
            line, buf = '', buf
    out.append(line + buf)
    return [x for x in out if x != ''] or ['']


def slugify(s):
    """把任意文本转成安全的文件名片段。"""
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', '_', str(s)).strip(' ._')
    return s or 'untitled'


def cjk_ratio(s):
    if not s:
        return 0.0
    n = sum(1 for c in s if '\u4e00' <= c <= '\u9fff')
    return n / max(1, len(s))
